#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 22:07:51 2020

@author: balderrama
"""

import pandas as pd


data_lowlands = {}
grid = {}
microgrids = {}
sa_pv = {}
sa_Diesel = {}

for i in ['018', '58', '1']:
    path = 'Diesel_' + i + '.csv'
    data = pd.read_csv(path)
    
    data_lowlands = data.loc[data['Elevation']<800]  
    
    grid[i] = data_lowlands.loc[data_lowlands['FinalElecCode2025']==1]
    
    microgrids[i] = data_lowlands.loc[data_lowlands['FinalElecCode2025'] ==4] 
    
    sa_pv[i] = data_lowlands.loc[data_lowlands['FinalElecCode2025'] ==3]
    
    sa_Diesel[i] = data_lowlands.loc[data_lowlands['FinalElecCode2025'] ==2]
